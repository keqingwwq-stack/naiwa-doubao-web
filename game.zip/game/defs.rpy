# ============================================================
#  奶娃与豆包 —— 定义：角色、图像、转场、章节卡
# ============================================================

# ---------------------------------------------------------- 声道 / 封面交互
init python:
    renpy.music.register_channel("ambient", mixer="sfx", loop=True, tight=True)

    import math as _aim_math

    AIM_ORIGIN = (1611, 362)      # 弓的中点，见 tools/titlegen.py
    ARM_PIVOT = (1545, 355)       # 肩关节：两条袖子的固定端（永远不动）
    REAR_ROOT = (1543, 342)       # 拉弦袖子的固定端
    ARM_RX = 92.0                 # 满幅椭圆水平半轴 = 最长臂长
    ARM_RY = 52.0                 # 满幅椭圆垂直半轴
    ARM_MAX_TILT = 38.0
    ARM_PHI_MAX = 52.0            # 椭圆参数角上限（渲染方向自然收敛在 ~36°）
    ARM_K_MIN = 0.46              # 鼠标贴身时椭圆缩到 46%
    ARM_K_MAX = 1.0               # 鼠标到屏幕边缘时椭圆满幅
    ARM_DIST_NEAR = 140.0         # 距离映射近端
    ARM_DIST_FAR = 900.0          # 距离映射远端
    SLEEVE_BASE = 68              # 袖子贴图原始长度
    SLEEVE_H = 24                 # 袖子贴图高度，肩端在 (0,12)
    SLEEVE_LEN_MIN = 26           # 预渲染袖子最短档
    SLEEVE_LEN_MAX = 94           # 预渲染袖子最长档
    SLEEVE_BOX = 200              # 袖子渲染框边长
    BOW_BOX = 128                 # 弓簇贴图边长
    BOW_ANCHOR = (64, 64)         # 弓簇握点在贴图中心
    BOW_PULL = 32                 # 握点到弦扣的距离
    ARM_IDLE_PERIOD = 9.0         # 静止时的椭圆呼吸周期
    ARM_IDLE_ANGLE = 3.0
    ARM_IDLE_REACH = 0.045

    def aim_state(mx, my):
        """纯函数：光标位置 -> (纸飞机角度, 是否瞄向左半边, 手臂摆角)。

        Ren'Py 的 rotate 是屏幕坐标下顺时针为正，可直接用 atan2(dy, dx)。
        身体烘焙进背景、永远不动；摆角同时决定椭圆上的方位和当前臂长。
        """
        ox, oy = AIM_ORIGIN
        theta = _aim_math.degrees(_aim_math.atan2(my - oy, mx - ox))
        left = _aim_math.cos(_aim_math.radians(theta)) < 0
        tilt = theta - 180.0 if left else theta
        while tilt > 180.0:
            tilt -= 360.0
        while tilt < -180.0:
            tilt += 360.0
        tilt = max(-ARM_MAX_TILT, min(ARM_MAX_TILT, tilt))
        return theta, left, tilt

    def ellipse_radius(ang):
        """以肩为心的椭圆在方向 ang 上的半径：平举最长、抬起最短。"""
        r = _aim_math.radians(ang)
        return (ARM_RX * ARM_RY /
                _aim_math.hypot(ARM_RY * _aim_math.cos(r),
                                ARM_RX * _aim_math.sin(r)))

    def arm_target(mx, my, t=0.0):
        """鼠标 + 时间 -> (手臂方向, 当前臂长)。

        肩端固定，自由端落在以肩为心的一族相似椭圆上：
            自由端 = (k * ARM_RX * cos(phi), k * ARM_RY * sin(phi))
        k 由鼠标到肩的距离决定：越远伸得越长（这是伸缩的主要来源）；
        phi 由鼠标方位决定：沿椭圆轨道滑动。压扁的椭圆让 phi 夹在
        ±52° 时渲染方向自然收敛在 ±36° 内，弓始终平举不垂到平台。

        旧版把臂长绑在被夹到 ±38° 的摆角上，鼠标一进屏幕下半部角度
        就饱和、臂长恒定，看起来「双臂不会延长」——已改为距离主导。
        另叠一圈 9 秒、幅度极小的椭圆呼吸，静止时也在缓缓伸缩。
        """
        ox, oy = AIM_ORIGIN
        theta = _aim_math.degrees(_aim_math.atan2(my - oy, mx - ox))
        left = _aim_math.cos(_aim_math.radians(theta)) < 0
        raw = theta - 180.0 if left else theta
        while raw > 180.0:
            raw -= 360.0
        while raw < -180.0:
            raw += 360.0
        phi = max(-ARM_PHI_MAX, min(ARM_PHI_MAX, raw))

        phase = 2.0 * _aim_math.pi * t / ARM_IDLE_PERIOD
        phi = max(-ARM_PHI_MAX, min(ARM_PHI_MAX,
                                    phi + ARM_IDLE_ANGLE * _aim_math.sin(phase)))

        dist = _aim_math.hypot(mx - ox, my - oy)
        s = max(0.0, min(1.0, (dist - ARM_DIST_NEAR) /
                         (ARM_DIST_FAR - ARM_DIST_NEAR)))
        k = ARM_K_MIN + (ARM_K_MAX - ARM_K_MIN) * s
        k *= 1.0 + ARM_IDLE_REACH * _aim_math.sin(phase + 1.1)
        k = max(ARM_K_MIN * 0.9, min(ARM_K_MAX * 1.03, k))

        r = _aim_math.radians(phi)
        ex = k * ARM_RX * _aim_math.cos(r)
        ey = k * ARM_RY * _aim_math.sin(r)
        reach = _aim_math.hypot(ex, ey)
        direction = _aim_math.degrees(_aim_math.atan2(ey, ex))
        if left:
            direction += 180.0
        return direction, reach

    def arm_pose(direction, reach):
        """解出整帧姿态：固定端钉死，自由端在椭圆上，袖子按长度拉伸。"""
        r = _aim_math.radians(direction)
        ux, uy = _aim_math.cos(r), _aim_math.sin(r)
        sx, sy = ARM_PIVOT
        gx, gy = sx + reach * ux, sy + reach * uy
        nx, ny = gx - BOW_PULL * ux, gy - BOW_PULL * uy
        rx, ry = REAR_ROOT
        rear_len = max(10.0, _aim_math.hypot(nx - rx, ny - ry))
        rear_dir = _aim_math.degrees(_aim_math.atan2(ny - ry, nx - rx))
        return {
            "direction": direction, "reach": reach,
            "gx": gx, "gy": gy, "nx": nx, "ny": ny,
            "front_root": (sx, sy), "rear_root": (rx, ry),
            "front_scale": reach / SLEEVE_BASE,
            "rear_scale": rear_len / SLEEVE_BASE,
            "rear_dir": rear_dir, "rear_len": rear_len,
        }

    class TitleCursor(renpy.Displayable):
        """主菜单光标：隐藏原来的系统鼠标，用纸飞机贴图顶上。

        作为 config.mouse_displayable 挂到最上层。_has_mouse_cursor() 为真时
        引擎会把硬件光标设为不可见，画面里就只剩这一枚纸飞机；离开主菜单
        （进剧情、设置、读取存档）返回假，硬件光标自动恢复。
        纸飞机只在这里画，不再连任何箭杆。
        """

        def __init__(self, **kwargs):
            super(TitleCursor, self).__init__(**kwargs)
            self.head = Transform("gui/aim_head.png")
            self.glow = Transform("images/bg/fx_glow_warm.png",
                                  xsize=120, ysize=120)

        def on_title(self):
            try:
                return renpy.get_screen("main_menu") is not None
            except Exception:
                return False

        def _has_mouse_cursor(self):
            return self.on_title()

        def render(self, width, height, st, at):
            rv = renpy.Render(width, height)
            renpy.redraw(self, 0)
            if not self.on_title() or not renpy.is_mouse_visible():
                return rv
            mx, my = renpy.get_mouse_pos()
            if mx <= 0 and my <= 0:   # 刚进主菜单、还没动鼠标
                mx, my = 900, 620
            angle, _, _ = aim_state(mx, my)
            soft = mx < 500           # 鼠标进左侧菜单区时收一点亮度

            # 尖端在贴图中心，整枚按方向旋转，正好落在光标上
            head_t = Transform(self.head, rotate=angle,
                               alpha=0.55 if soft else 1.0)
            hr = renpy.render(head_t, 96, 96, st, at)
            rv.blit(hr, (int(mx - 48), int(my - 48)))
            gr = renpy.render(self.glow, 120, 120, st, at)
            rv.blit(gr, (int(mx - 60), int(my - 60)))
            return rv

        def visit(self):
            return [self.head, self.glow]

        def event(self, ev, x, y, st):
            return None               # 事件透传给下面的按钮

    class AimingBowarm(renpy.Displayable):
        """肩端固定、自由端沿相似椭圆滑动的可伸缩双臂。

        身体是背景的一部分，永远不动。两条袖子的根部分别钉在
        ARM_PIVOT / REAR_ROOT；臂长由 arm_target() 按鼠标距离算出
        （26~94px），运行时挑一张对应长度的预渲染袖子贴图，再绕
        固定端旋转，于是「肩不动、手伸出去」。弓簇完全不缩放，
        只跟着方向转，所以弓不会被拉变形。方向与臂长都做了缓动。
        """

        def __init__(self, **kwargs):
            super(AimingBowarm, self).__init__(**kwargs)
            self.bow = renpy.displayable("gui/bowarm.png")
            # 长度档位预先渲染成 PNG：先拉伸、后旋转的顺序完全确定，
            # 也不用被 lint 判为过时的图像操作符。
            self.sleeves = {}
            for L in range(SLEEVE_LEN_MIN, SLEEVE_LEN_MAX + 1, 2):
                self.sleeves[L] = renpy.displayable("gui/sleeves/s_%03d.png" % L)
            self.direction = 0.0
            self.reach = ARM_RX * 0.75

        def _sleeve(self, length, angle, st, at):
            L = max(SLEEVE_LEN_MIN, min(SLEEVE_LEN_MAX,
                                        int(round(length / 2.0)) * 2))
            child = self.sleeves.get(L, self.sleeves[SLEEVE_BASE])
            half = SLEEVE_BOX // 2
            # 贴图本身就是 200×200、固定端在正中心的透明画布。
            # rotate_pad 必须打开：关闭时引擎仍会把「旋转外接框」的半幅偏移
            # 算进位置，却又不扩大画布，袖子会整体飘离肩膀约 28px。
            t = Transform(child,
                          xanchor=half, yanchor=half,
                          rotate=angle,
                          rotate_pad=True)
            return renpy.render(t, SLEEVE_BOX, SLEEVE_BOX, st, at)

        def _blit_center(self, rv, cr, cx, cy):
            """绕中心旋转后的 Render 会被扩边；按实际尺寸把中心贴回目标点。"""
            cw, ch = cr.get_size()
            rv.blit(cr, (int(cx - cw / 2.0), int(cy - ch / 2.0)))

        def render(self, width, height, st, at):
            rv = renpy.Render(1920, 1080)
            mx, my = renpy.get_mouse_pos()
            if mx <= 0 and my <= 0:
                mx, my = 900, 620
            target_dir, target_reach = arm_target(mx, my, st)
            delta = (target_dir - self.direction + 180.0) % 360.0 - 180.0
            self.direction += delta * 0.18
            self.reach += (target_reach - self.reach) * 0.16
            p = arm_pose(self.direction, self.reach)

            # 后袖子（拉弦）压在下面，前袖子（持弓）压在上面
            rr = self._sleeve(p["rear_len"], p["rear_dir"], st, at)
            self._blit_center(rv, rr,
                              p["rear_root"][0], p["rear_root"][1])
            fr = self._sleeve(p["reach"], p["direction"], st, at)
            self._blit_center(rv, fr,
                              p["front_root"][0], p["front_root"][1])

            bh = BOW_BOX // 2
            bt = Transform(self.bow,
                           xanchor=0.5, yanchor=0.5,
                           rotate=p["direction"],
                           rotate_pad=True)
            br = renpy.render(bt, BOW_BOX, BOW_BOX, st, at)
            self._blit_center(rv, br, p["gx"], p["gy"])

            renpy.redraw(self, 0)
            return rv

        def visit(self):
            return [self.bow] + list(self.sleeves.values())

        def event(self, ev, x, y, st):
            return None

    config.mouse_displayable = TitleCursor()


define aiming_bowarm = AimingBowarm()


# ---------------------------------------------------------- 角色
define n = Character("奶娃", color="#d8b06a", what_color="#f2e9d8")
define d = Character("豆包", color="#d98b84", what_color="#f2e9d8")
define db = Character("窦宝", color="#d98b84", what_color="#f2e9d8")
define g = Character("国王", color="#c9b27a", what_color="#f2e9d8")
define c = Character("老队长", color="#8fb8c9", what_color="#f2e9d8")
define v = Character("侍从", color="#9aa0a8", what_color="#f2e9d8")
define m = Character("村长", color="#b0a68f", what_color="#f2e9d8")

define narr = Character(None, what_color="#e7ddca")
define nt = Character(None, what_color="#b6ada0")


# ---------------------------------------------------------- 背景与 CG
image bg title = "images/bg/title.png"
image bg town = "images/bg/town_rain.jpg"
image bg town day = "images/bg/town_day.png"
image bg mill = "images/bg/mill.jpg"
image bg slope = "images/bg/slope.jpg"
image bg tower = "images/bg/tower.jpg"
image bg snow = "images/bg/snowroad.jpg"
image bg hut = "images/bg/hut.jpg"
image bg hut winter = "images/bg/hut_winter.png"
image bg hut spring = "images/bg/hut_spring.png"
image bg beacon = "images/bg/beacon.png"
image bg castle gate = "images/bg/castle_gate.png"
image bg road = "images/bg/road_dusk.jpg"

image cg throne = "images/cg/throne.jpg"
image cg cliff = "images/cg/cliff.jpg"


# ---------------------------------------------------------- 立绘
image na armor = "images/chara/naiwa_armor.png"
image na armor_side = "images/chara/naiwa_armor_side.png"
image na coat = "images/chara/naiwa_coat.png"
image na coat2 = "images/chara/naiwa_coat2.png"
image na leaf = "images/chara/naiwa_leaf.png"
image na leaf_side = "images/chara/naiwa_leaf_side.png"

image db dress = "images/chara/doubao_dress.png"
image db leaf = "images/chara/doubao_leaf.png"
image db leaf_side = "images/chara/doubao_leaf_side.png"

image kg = "images/chara/king.png"
image kg side = "images/chara/king_side.png"


# ---------------------------------------------------------- 转场
define slowfade = Fade(0.9, 0.3, 0.9)
define quickfade = Dissolve(0.45)
define toblack = Fade(0.5, 0.35, 0.0)


# ---------------------------------------------------------- 站位
transform stand_l:
    xalign 0.17
    yalign 1.0
    zoom 0.78

transform stand_r:
    xalign 0.83
    yalign 1.0
    zoom 0.78

transform stand_c:
    xalign 0.50
    yalign 1.0
    zoom 0.78

transform close_l:
    xalign 0.26
    yalign 1.0
    zoom 0.86

transform close_r:
    xalign 0.74
    yalign 1.0
    zoom 0.86


# ---------------------------------------------------------- 天气层
image rain:
    contains:
        "images/bg/fx_rain.png"
        ypos -1080
        linear 0.55 ypos 0
        repeat

image rain_soft:
    contains:
        "images/bg/fx_rain_soft.png"
        ypos -1080
        linear 1.10 ypos 0
        repeat

image snowfx:
    contains:
        "images/bg/fx_snow.png"
        ypos -1080
        linear 4.20 ypos 0
        repeat

# 主菜单专用：同一张雪，速度只有剧情里的三分之一，不显晃
image title_snow:
    contains:
        "images/bg/fx_snow.png"
        ypos -1080
        linear 14.0 ypos 0
        repeat

image dustfx:
    contains:
        "images/bg/fx_dust.png"
        ypos -1080
        linear 8.00 ypos 0
        repeat


# ---------------------------------------------------------- 氛围层
# 带 alpha 的柔光贴图（tools/artgen_v2.py 的 fx 出品）。
# 放在「scene 之后、立绘之前」，只给场景一点呼吸，不会盖住人。

image haze:
    "images/bg/fx_haze.png"
    ypos 560
    alpha 0.60
    block:
        xpos -480
        linear 46 xpos 0
        linear 46 xpos -480
        repeat

image hearth:
    "images/bg/fx_glow_warm.png"
    xzoom 1.95
    yzoom 1.25
    xpos 460
    ypos 420
    alpha 0.38
    block:
        linear 0.9 alpha 0.55
        linear 1.4 alpha 0.32
        repeat

image lantern:
    "images/bg/fx_glow_warm.png"
    xzoom 0.86
    yzoom 0.74
    xpos 910
    ypos 650
    alpha 0.34
    block:
        linear 2.2 alpha 0.46
        linear 2.6 alpha 0.28
        repeat

image torch:
    "images/bg/fx_glow_warm.png"
    xzoom 2.34
    yzoom 1.09
    xpos 360
    ypos 400
    alpha 0.30
    block:
        linear 0.7 alpha 0.44
        linear 1.1 alpha 0.26
        repeat

image beaconfire:
    "images/bg/fx_glow_warm.png"
    xzoom 1.05
    yzoom 0.86
    xpos 1090
    ypos 230
    alpha 0.46
    block:
        linear 1.1 alpha 0.68
        linear 1.7 alpha 0.38
        repeat


# ---------------------------------------------------------- 镜头
transform camera_drift:
    zoom 1.05
    xalign 0.5
    yalign 0.5
    linear 26 zoom 1.0


# ---------------------------------------------------------- 封面
# 主菜单是一张静帧，只留一点几乎察觉不到的呼吸：
# 幅度从 5% 收到 1.2%，周期 60 秒拉到 90 秒；雪另用 14 秒一轮的慢层。
transform title_drift:
    zoom 1.012
    xalign 0.5
    yalign 0.5
    linear 45 zoom 1.0
    linear 45 zoom 1.012
    repeat


transform logo_intro:
    alpha 0.0
    yoffset 18
    linear 1.5 alpha 1.0 yoffset 0


# ---------------------------------------------------------- 章节卡
screen chapter_card(num, title, sub):
    zorder 100

    add Solid("#0a0c10")

    vbox:
        xalign 0.5
        yalign 0.44
        spacing 26

        text num:
            xalign 0.5
            font "fonts/simkai.ttf"
            size 40
            color "#c9a25c"

        add Solid("#7d6a44"):
            xalign 0.5
            xsize 150
            ysize 1

        text title:
            xalign 0.5
            font "fonts/simkai.ttf"
            size 78
            color "#f4e9d2"

        text sub:
            xalign 0.5
            font "fonts/SourceHanSansLite.ttf"
            size 25
            color "#968a77"

label chapter(num, title, sub):

    window hide

    scene black
    show screen chapter_card(num, title, sub)
    with Dissolve(0.8)

    $ renpy.pause(2.0)

    hide screen chapter_card
    with Dissolve(0.8)

    return


label clear_stage:

    hide na armor
    hide na armor_side
    hide na coat
    hide na coat2
    hide na leaf
    hide na leaf_side
    hide db dress
    hide db leaf
    hide db leaf_side
    hide kg
    hide kg side
    hide rain
    hide rain_soft
    hide snowfx
    hide dustfx
    hide haze
    hide hearth
    hide lantern
    hide torch
    hide beaconfire

    return
