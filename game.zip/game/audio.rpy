define audio.theme_calm = "audio/theme_calm.ogg"
define audio.theme_tense = "audio/theme_tense.ogg"
define audio.theme_north = "audio/theme_north.ogg"

define audio.amb_rain = "audio/amb_rain.ogg"
define audio.amb_wind = "audio/amb_wind.ogg"
define audio.amb_fire = "audio/amb_fire.ogg"

define audio.sfx_ui = "audio/sfx_ui.ogg"
define audio.sfx_horse = "audio/sfx_horse.ogg"
