# ============================================================
#  奶娃与豆包 —— 互动小游戏（第二版）
#
#  三关都长在剧情里，不做独立的小游戏菜单：
#    数砖    —— 北塔，第三章。她敲墙听空响，把声音记住。
#              最后一块永远是从东边数第七块，和驿馆后墙的那块砖对上。
#    烤饼    —— 石屋，第五章。火会自己走，火候分起火 / 稳火 / 收火三段。
#    敲三下  —— 悬崖，第七章。望楼换岗的暗号，追兵正在上来。
#
#  约定：
#    call screen 之后读 _return：True 成功，False 失败。
#    「略过」返回 True，等价于一次不完美的通过，不会卡住剧情。
#    每关写 mg_*_perfect，剧本和尾声会据此给一句回响。
#    失败由剧本负责给台阶：重来一次，第二回降低难度。
# ============================================================


# ---------------------------------------------------------- 公共
init python:
    import math as _mg_math

    def mg_clip(v, lo, hi):
        if v < lo:
            return lo
        if v > hi:
            return hi
        return v

    def mg_sfx():
        renpy.play(audio.sfx_ui, channel="sound")

    def mg_skip(which):
        # 无障碍：跳过不惩罚，只标记为不完美
        store.mg_brick_perfect = False if which == "brick" else store.mg_brick_perfect
        store.mg_fire_perfect = False if which == "fire" else store.mg_fire_perfect
        store.mg_knock_perfect = False if which == "knock" else store.mg_knock_perfect


style mg_button:
    padding (40, 14)
    background Solid("#241f19")
    hover_background Solid("#3b3227")

style mg_small_button:
    padding (18, 8)
    background Solid("#1a1713")
    hover_background Solid("#332b21")


# ============================================================
#  关卡一 · 数砖
#  12 块墙砖，亮起的是空心的。最后一块固定是第七块。
#  可「再听一遍」一次；点错三次算数乱了。
# ============================================================
default mg_brick_phase = "idle"
default mg_brick_targets = []
default mg_brick_found = []
default mg_brick_wrong = 0
default mg_brick_lit = -1
default mg_brick_show_i = 0
default mg_brick_replay = 1
default mg_brick_miss = -1
default mg_brick_hint = ""
default mg_brick_perfect = False
default mg_brick_count = 4

init python:

    def mg_brick_bg(i):
        if i == store.mg_brick_lit:
            return Solid("#e2bb74")
        if i == store.mg_brick_miss:
            return Solid("#7c4038")
        if i in store.mg_brick_found:
            return Solid("#4c6a41")
        return Solid("#241f19")

    def mg_bricks_start(count=4, forgiving=False):
        # 6 号砖 = 从东边数第七块，永远最后亮，衔接「第七块」这条伏笔
        pool = [i for i in range(12) if i != 6]
        picked = list(renpy.random.sample(pool, max(0, count - 1)))
        picked.append(6)
        store.mg_brick_targets = picked
        store.mg_brick_count = len(picked)
        store.mg_brick_found = []
        store.mg_brick_wrong = 0
        store.mg_brick_miss = -1
        store.mg_brick_replay = 1 if not forgiving else 2
        store.mg_brick_perfect = False
        mg_brick_rewind()
        renpy.restart_interaction()

    def mg_brick_rewind():
        store.mg_brick_lit = -1
        store.mg_brick_show_i = 0
        store.mg_brick_found = []
        store.mg_brick_phase = "show"
        store.mg_brick_hint = "她一块一块敲过去。亮起来的，是空心的。"
        renpy.restart_interaction()

    def mg_brick_flash():
        # 一步亮、一步灭；0.5 秒一步
        total = len(store.mg_brick_targets) * 2
        if store.mg_brick_show_i >= total:
            store.mg_brick_phase = "input"
            store.mg_brick_lit = -1
            store.mg_brick_hint = "把刚才响过的砖，一块一块点出来。"
            renpy.restart_interaction()
            return

        if store.mg_brick_show_i % 2 == 0:
            store.mg_brick_lit = store.mg_brick_targets[store.mg_brick_show_i // 2]
        else:
            store.mg_brick_lit = -1

        store.mg_brick_show_i += 1
        renpy.restart_interaction()

    def mg_brick_clear_miss():
        store.mg_brick_miss = -1
        renpy.restart_interaction()

    def mg_brick_click(i):
        if store.mg_brick_phase != "input":
            return
        if i in store.mg_brick_found:
            return

        if i in store.mg_brick_targets:
            store.mg_brick_found.append(i)
            mg_sfx()
            if len(store.mg_brick_found) >= len(store.mg_brick_targets):
                store.mg_brick_phase = "win"
                store.mg_brick_perfect = (store.mg_brick_wrong == 0)
                store.mg_brick_hint = "数清了。最后一块，是第七块。"
            else:
                store.mg_brick_hint = "空的。还差 %d 块。" % (len(store.mg_brick_targets) - len(store.mg_brick_found))
        else:
            store.mg_brick_wrong += 1
            store.mg_brick_miss = i
            if store.mg_brick_wrong >= 3:
                store.mg_brick_phase = "lose"
                store.mg_brick_hint = "数乱了。"
            else:
                store.mg_brick_hint = "这块是实的。还可以错 %d 次。" % (3 - store.mg_brick_wrong)

        renpy.restart_interaction()


screen mg_bricks():
    modal True
    zorder 150

    add "bg tower"
    add Solid("#05060ad0")

    frame:
        xalign 0.5
        yalign 0.5
        background Solid("#0b0d11e8")
        padding (70, 44)

        vbox:
            spacing 22

            text "数 砖":
                xalign 0.5
                font "fonts/simkai.ttf"
                size 52
                color "#f4e9d2"

            text mg_brick_hint:
                xalign 0.5
                font "fonts/SourceHanSansLite.ttf"
                size 25
                color "#a89a83"

            grid 4 3:
                xalign 0.5
                spacing 14

                for i in range(12):
                    button:
                        xysize (150, 92)
                        background mg_brick_bg(i)
                        hover_background mg_brick_bg(i)
                        sensitive (mg_brick_phase == "input")
                        action Function(mg_brick_click, i)
                        if i in mg_brick_found:
                            text str(mg_brick_found.index(i) + 1):
                                xalign 0.5
                                yalign 0.5
                                font "fonts/simkai.ttf"
                                size 30
                                color "#e7ddca"

            hbox:
                xalign 0.5
                spacing 30

                text ("响过 %d 块 · 找出 %d 块 · 错 %d 次" % (mg_brick_count, len(mg_brick_found), mg_brick_wrong)):
                    font "fonts/SourceHanSansLite.ttf"
                    size 23
                    color "#7d7365"

                if mg_brick_phase == "input" and mg_brick_replay > 0:
                    textbutton "再 听 一 遍":
                        style "mg_small_button"
                        text_font "fonts/SourceHanSansLite.ttf"
                        text_size 21
                        text_color "#c9a25c"
                        text_hover_color "#f4e9d2"
                        action [Function(mg_brick_dec_replay), Function(mg_brick_rewind)]

            textbutton "略 过":
                xalign 0.5
                style "mg_small_button"
                text_font "fonts/SourceHanSansLite.ttf"
                text_size 20
                text_color "#6d6457"
                text_hover_color "#c9a25c"
                action [Function(mg_skip, "brick"), Return(True)]

    if mg_brick_miss >= 0:
        timer 0.4 action Function(mg_brick_clear_miss)
    if mg_brick_phase == "show":
        timer 0.5 repeat True action Function(mg_brick_flash)
    if mg_brick_phase == "win":
        timer 1.0 action Return(True)
    if mg_brick_phase == "lose":
        timer 1.3 action Return(False)


init python:
    def mg_brick_dec_replay():
        store.mg_brick_replay -= 1


# ============================================================
#  关卡二 · 烤饼
#  火候三段：起火 52–78 / 稳火 34–66 / 收火 26–52。
#  火会自己往下走，也会烧过头；添柴撤柴有短冷却，不能连点。
# ============================================================
default mg_fire_v = 50.0
default mg_fire_hold = 0.0
default mg_fire_t = 0.0
default mg_fire_phase = "idle"
default mg_fire_hint = ""
default mg_fire_zone_lo = 52.0
default mg_fire_zone_hi = 78.0
default mg_fire_stage = 0
default mg_fire_burn = 0.0
default mg_fire_cd = 0.0
default mg_fire_perfect = False
default mg_fire_easier = False

init python:

    def mg_fire_start(easier=False):
        store.mg_fire_v = 50.0
        store.mg_fire_hold = 0.0
        store.mg_fire_t = 0.0
        store.mg_fire_burn = 0.0
        store.mg_fire_cd = 0.0
        store.mg_fire_stage = 0
        store.mg_fire_zone_lo = 52.0
        store.mg_fire_zone_hi = 78.0
        store.mg_fire_phase = "run"
        store.mg_fire_perfect = False
        store.mg_fire_easier = easier
        store.mg_fire_hint = "先把火烧起来。灰里还有火星。"
        renpy.restart_interaction()

    def mg_fire_tick(dt=0.08):
        if store.mg_fire_phase != "run":
            return

        store.mg_fire_t += dt
        t = store.mg_fire_t
        store.mg_fire_cd = max(0.0, store.mg_fire_cd - dt)

        # 三段火候，绿区自己会挪
        if t < 2.2:
            stage, lo, hi, tip = 0, 52.0, 78.0, "起火 · 要旺一点"
        elif t < 5.0:
            stage, lo, hi, tip = 1, 34.0, 66.0, "稳火 · 别让它跑"
        else:
            stage, lo, hi, tip = 2, 26.0, 52.0, "收火 · 撤一根，等焦花"
        if store.mg_fire_easier:
            lo, hi = max(20.0, lo - 6.0), min(88.0, hi + 6.0)
        store.mg_fire_stage = stage
        store.mg_fire_zone_lo = lo
        store.mg_fire_zone_hi = hi

        drift = -6.2 + 5.2 * _mg_math.sin(t * 1.3) + 3.0 * _mg_math.sin(t * 2.9 + 0.7)
        store.mg_fire_v = mg_clip(store.mg_fire_v + drift * dt, 0.0, 100.0)

        v = store.mg_fire_v
        if lo <= v <= hi:
            store.mg_fire_hold += dt * 0.72
            store.mg_fire_hint = "正好。"
        else:
            store.mg_fire_hold = max(0.0, store.mg_fire_hold - dt * 0.35)
            store.mg_fire_hint = "火太小了。添柴。" if v < lo else "火大了。撤一根。"

        if v > 88.0:
            store.mg_fire_burn += dt
        else:
            store.mg_fire_burn = max(0.0, store.mg_fire_burn - dt * 0.5)

        if store.mg_fire_hold >= 5.0:
            store.mg_fire_phase = "win"
            store.mg_fire_perfect = (store.mg_fire_burn < 0.3)
            store.mg_fire_hint = "面上起了焦花。"
        elif v <= 0.5:
            store.mg_fire_phase = "lose"
            store.mg_fire_hint = "火灭了。"
        elif v >= 99.5 or store.mg_fire_burn >= 2.6:
            store.mg_fire_phase = "lose"
            store.mg_fire_hint = "糊了。"

        renpy.restart_interaction()

    def mg_fire_bump(dv):
        if store.mg_fire_phase != "run" or store.mg_fire_cd > 0.0:
            return
        store.mg_fire_v = mg_clip(store.mg_fire_v + dv, 0.0, 100.0)
        store.mg_fire_cd = 0.22
        mg_sfx()
        renpy.restart_interaction()

    def mg_fire_flame():
        v = store.mg_fire_v
        if v < 25.0:
            return Solid("#6a3122")
        if v < 45.0:
            return Solid("#a0552c")
        if v < 68.0:
            return Solid("#d08a3e")
        if v < 88.0:
            return Solid("#e8bb62")
        return Solid("#f4e2b0")

    def mg_fire_stage_name():
        return ["起火", "稳火", "收火"][store.mg_fire_stage]


screen mg_fire():
    modal True
    zorder 150

    key "K_UP" action Function(mg_fire_bump, 9.0)
    key "K_DOWN" action Function(mg_fire_bump, -9.0)

    add "bg hut winter"
    add Solid("#05060ad8")

    frame:
        xalign 0.5
        yalign 0.5
        background Solid("#0b0d11e8")
        padding (70, 44)

        vbox:
            spacing 24

            text "烤 饼":
                xalign 0.5
                font "fonts/simkai.ttf"
                size 52
                color "#f4e9d2"

            text mg_fire_hint:
                xalign 0.5
                font "fonts/SourceHanSansLite.ttf"
                size 25
                color "#a89a83"

            # 火苗：颜色跟着火力走
            fixed:
                xysize (880, 26)
                add Solid("#171310")
                add mg_fire_flame():
                    xsize int(store.mg_fire_v / 100.0 * 880.0)
                    ysize 26

            # 火候条：绿区随阶段移动
            fixed:
                xysize (880, 46)
                add Solid("#171310")
                add Solid("#33482e"):
                    xpos int(store.mg_fire_zone_lo / 100.0 * 864.0)
                    xsize int((store.mg_fire_zone_hi - store.mg_fire_zone_lo) / 100.0 * 864.0)
                    ysize 46
                add Solid("#e8c98c"):
                    xpos int(store.mg_fire_v / 100.0 * 864.0)
                    xsize 8
                    ysize 46

            hbox:
                xalign 0.0
                spacing 20
                text ("%s · 火候 %d–%d" % (mg_fire_stage_name(), int(mg_fire_zone_lo), int(mg_fire_zone_hi))):
                    font "fonts/SourceHanSansLite.ttf"
                    size 21
                    color "#8a9a7c"
                text ("熟度 %d%%" % int(min(store.mg_fire_hold / 5.0, 1.0) * 100)):
                    font "fonts/SourceHanSansLite.ttf"
                    size 21
                    color "#c9a25c"

            fixed:
                xysize (880, 8)
                add Solid("#171310")
                add Solid("#c9a25c"):
                    xsize int(min(store.mg_fire_hold / 5.0, 1.0) * 880.0)
                    ysize 8

            hbox:
                xalign 0.5
                spacing 36

                textbutton "添 柴":
                    style "mg_button"
                    text_font "fonts/simkai.ttf"
                    text_size 30
                    text_color "#e7ddca"
                    text_hover_color "#f4e9d2"
                    sensitive (mg_fire_phase == "run" and mg_fire_cd <= 0.0)
                    action Function(mg_fire_bump, 9.0)

                textbutton "撤 一根":
                    style "mg_button"
                    text_font "fonts/simkai.ttf"
                    text_size 30
                    text_color "#e7ddca"
                    text_hover_color "#f4e9d2"
                    sensitive (mg_fire_phase == "run" and mg_fire_cd <= 0.0)
                    action Function(mg_fire_bump, -9.0)

            text "↑ 添柴　↓ 撤一根　·　火会自己往下走":
                xalign 0.5
                font "fonts/SourceHanSansLite.ttf"
                size 20
                color "#6d6457"

            textbutton "略 过":
                xalign 0.5
                style "mg_small_button"
                text_font "fonts/SourceHanSansLite.ttf"
                text_size 20
                text_color "#6d6457"
                text_hover_color "#c9a25c"
                action [Function(mg_skip, "fire"), Return(True)]

    if mg_fire_phase == "run":
        timer 0.08 repeat True action Function(mg_fire_tick)
    if mg_fire_phase == "win":
        timer 1.0 action Return(True)
    if mg_fire_phase == "lose":
        timer 1.3 action Return(False)


# ============================================================
#  关卡三 · 敲三下
#  望楼换岗的暗号：三下，敲在石头上。
#  追兵在上山；三次命中窗口逐次收窄，敲空会把人引过来。
# ============================================================
default mg_knock_pos = 0.0
default mg_knock_dir = 1.0
default mg_knock_hits = 0
default mg_knock_taps = 0
default mg_knock_misses = 0
default mg_knock_pursuit = 100.0
default mg_knock_pause = 0.0
default mg_knock_speed = 0.75
default mg_knock_phase = "idle"
default mg_knock_hint = ""
default mg_knock_perfect = False
default mg_knock_easier = False

init python:

    def mg_knock_window():
        if store.mg_knock_easier:
            return (0.28, 0.72)
        return [(0.30, 0.70), (0.34, 0.66), (0.38, 0.62)][min(store.mg_knock_hits, 2)]

    def mg_knock_start(easier=False):
        store.mg_knock_pos = 0.0
        store.mg_knock_dir = 1.0
        store.mg_knock_hits = 0
        store.mg_knock_taps = 0
        store.mg_knock_misses = 0
        store.mg_knock_pursuit = 100.0
        store.mg_knock_pause = 0.0
        store.mg_knock_speed = 0.68 if easier else 0.75
        store.mg_knock_phase = "run"
        store.mg_knock_perfect = False
        store.mg_knock_easier = easier
        store.mg_knock_hint = "石头落进那块亮着的地方。三下。"
        renpy.restart_interaction()

    def mg_knock_tick(dt=0.04):
        if store.mg_knock_phase not in ("run", "pause"):
            return

        if store.mg_knock_phase == "pause":
            store.mg_knock_pause -= dt
            if store.mg_knock_pause <= 0.0:
                store.mg_knock_phase = "run"
            renpy.restart_interaction()
            return

        store.mg_knock_pos += store.mg_knock_dir * store.mg_knock_speed * dt
        if store.mg_knock_pos >= 1.0:
            store.mg_knock_pos = 1.0
            store.mg_knock_dir = -1.0
        elif store.mg_knock_pos <= 0.0:
            store.mg_knock_pos = 0.0
            store.mg_knock_dir = 1.0

        store.mg_knock_pursuit -= dt * (1.9 if store.mg_knock_easier else 2.7)
        if store.mg_knock_pursuit <= 0.0:
            store.mg_knock_pursuit = 0.0
            store.mg_knock_phase = "lose"
            store.mg_knock_hint = "林子里已经很近了。"

        renpy.restart_interaction()

    def mg_knock_tap():
        if store.mg_knock_phase != "run":
            return

        store.mg_knock_taps += 1
        lo, hi = mg_knock_window()

        if lo <= store.mg_knock_pos <= hi:
            store.mg_knock_hits += 1
            mg_sfx()
            if store.mg_knock_hits >= 3:
                store.mg_knock_phase = "win"
                store.mg_knock_perfect = (store.mg_knock_misses == 0)
                store.mg_knock_hint = "三下。一下比一下实。"
            else:
                store.mg_knock_phase = "pause"
                store.mg_knock_pause = 0.34
                store.mg_knock_pos = 0.0
                store.mg_knock_dir = 1.0
                store.mg_knock_speed = 0.68 if store.mg_knock_easier else [0.75, 0.95, 1.15][store.mg_knock_hits]
                store.mg_knock_hint = "咚。第 %d 下。" % (store.mg_knock_hits + 1)
        else:
            store.mg_knock_misses += 1
            store.mg_knock_pursuit = max(0.0, store.mg_knock_pursuit - 11.0)
            store.mg_knock_hint = "擦过去了。石头声传得很远。"
            if store.mg_knock_misses >= 4 or store.mg_knock_pursuit <= 0.0:
                store.mg_knock_phase = "lose"
                store.mg_knock_hint = "敲乱了。林子里有人抬头。"

        renpy.restart_interaction()

    def mg_knock_bar():
        p = store.mg_knock_pursuit
        if p > 60.0:
            return Solid("#4c6a41")
        if p > 30.0:
            return Solid("#a8843c")
        return Solid("#8e4336")


screen mg_knock():
    modal True
    zorder 150

    key "K_SPACE" action Function(mg_knock_tap)
    key "K_RETURN" action Function(mg_knock_tap)
    key "K_KP_ENTER" action Function(mg_knock_tap)

    add "cg cliff"
    add Solid("#04050ae0")

    frame:
        xalign 0.5
        yalign 0.5
        background Solid("#0b0d11e8")
        padding (70, 44)

        vbox:
            spacing 24

            text "敲 三 下":
                xalign 0.5
                font "fonts/simkai.ttf"
                size 52
                color "#f4e9d2"

            text mg_knock_hint:
                xalign 0.5
                font "fonts/SourceHanSansLite.ttf"
                size 25
                color "#a89a83"

            fixed:
                xysize (880, 46)
                add Solid("#171310")
                add Solid("#3d4a5c"):
                    xpos int(mg_knock_window()[0] * 872.0)
                    xsize int((mg_knock_window()[1] - mg_knock_window()[0]) * 872.0)
                    ysize 46
                add Solid("#e8c98c"):
                    xpos int(store.mg_knock_pos * 872.0)
                    xsize 8
                    ysize 46

            hbox:
                xalign 0.5
                spacing 26
                for k in range(3):
                    if k < mg_knock_hits:
                        add Solid("#d8b06a"):
                            xysize (26, 26)
                    else:
                        add Solid("#2a241d"):
                            xysize (26, 26)

            fixed:
                xysize (880, 8)
                add Solid("#171310")
                add mg_knock_bar():
                    xsize int(store.mg_knock_pursuit / 100.0 * 880.0)
                    ysize 8

            text "追兵还在林子里 · 空格 / 回车 / 点「敲」":
                xalign 0.5
                font "fonts/SourceHanSansLite.ttf"
                size 20
                color "#6d6457"

            textbutton "敲":
                xalign 0.5
                style "mg_button"
                text_font "fonts/simkai.ttf"
                text_size 34
                text_color "#e7ddca"
                text_hover_color "#f4e9d2"
                sensitive (mg_knock_phase == "run")
                action Function(mg_knock_tap)

            textbutton "略 过":
                xalign 0.5
                style "mg_small_button"
                text_font "fonts/SourceHanSansLite.ttf"
                text_size 20
                text_color "#6d6457"
                text_hover_color "#c9a25c"
                action [Function(mg_skip, "knock"), Return(True)]

    if mg_knock_phase in ("run", "pause"):
        timer 0.04 repeat True action Function(mg_knock_tick)
    if mg_knock_phase == "win":
        timer 1.2 action Return(True)
    if mg_knock_phase == "lose":
        timer 1.3 action Return(False)
